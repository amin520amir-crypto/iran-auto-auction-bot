# ربات مزایده خودرو ایران — نسخه آماده Build آنلاین

این نسخه برای ساخت APK در GitHub Actions آماده شده است.

## ساخت APK فقط با گوشی
1. یک repository جدید در GitHub بسازید.
2. محتوای این ZIP را در repository قرار دهید.
3. در GitHub وارد تب **Actions** شوید.
4. workflow با نام **Build APK** را انتخاب کنید.
5. گزینه **Run workflow** را بزنید.
6. پس از پایان موفق، در بخش **Artifacts** فایل `iran-auto-auction-debug-apk` را دانلود کنید.
7. فایل APK را روی گوشی نصب کنید.

GitHub Actions از JDK 17 و Gradle 9.4.1 استفاده می‌کند. پروژه با Android Gradle Plugin 9.2.0 تنظیم شده است.

## نکته
این APK فعلاً نسخه MVP است. داده‌های نمونه برای تست رابط دارد. برای پایش واقعی مزایده‌های ایران باید collectorهای منابع رسمی و سرویس اعلان Push در مرحله بعد اضافه شوند.
