package com.amin.auctionbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.browser.customtabs.CustomTabsIntent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

private const val BASE_URL = "http://10.0.2.2:8000/"

data class Auction(
    val id: String, val title: String, val brand: String, val model: String,
    val year: Int, val province: String, val city: String, val base_price: Long,
    val deadline: String, val organizer: String, val url: String, val description: String
)

interface AuctionApi {
    @GET("auctions")
    suspend fun getAuctions(
        @Query("province") province: String? = null,
        @Query("model") model: String? = null,
        @Query("max_price") maxPrice: Long? = null
    ): List<Auction>
}

class AuctionViewModel : ViewModel() {
    private val api = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(AuctionApi::class.java)

    var auctions by mutableStateOf<List<Auction>>(emptyList())
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun load(province: String, model: String) {
        viewModelScope.launch {
            loading = true; error = null
            try {
                auctions = api.getAuctions(
                    province = province.ifBlank { null },
                    model = model.ifBlank { null }
                )
            } catch (e: Exception) {
                error = "ارتباط با سرور برقرار نشد"
            } finally { loading = false }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuctionApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuctionApp(vm: AuctionViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var province by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("🚗 مزایده خودرو ایران") })
        }) { pad ->
            Column(
                Modifier.padding(pad).padding(12.dp).fillMaxSize()
            ) {
                Text("پایش مزایده‌های خودرو", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = province, onValueChange = { province = it },
                    label = { Text("استان (خالی = همه)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = model, onValueChange = { model = it },
                    label = { Text("مدل خودرو، مثلاً 405") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { vm.load(province, model) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("جستجوی مزایده‌های جدید") }

                if (vm.loading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

                LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.auctions) { a ->
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(a.title, style = MaterialTheme.typography.titleMedium)
                                Text("📍 ${a.city}، ${a.province}")
                                Text("🏛 ${a.organizer}")
                                Text("📅 مهلت: ${a.deadline}")
                                if (a.year > 0) Text("🚘 مدل: ${a.year}")
                                Spacer(Modifier.height(6.dp))
                                OutlinedButton(onClick = {
                                    CustomTabsIntent.Builder().build()
                                        .launchUrl(context, Uri.parse(a.url))
                                }) { Text("مشاهده آگهی") }
                            }
                        }
                    }
                }
            }
        }
    }
}
