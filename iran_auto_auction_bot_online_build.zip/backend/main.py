from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import Optional
import re

app = FastAPI(title="Iran Auto Auction Bot")

# نمونه داده برای تست رابط کاربری.
# در نسخه عملی، این لیست توسط collectorهای منابع رسمی پر می‌شود.
AUCTIONS = [
    {
        "id": "demo-405-1384-ramian",
        "title": "مزایده خودرو سواری پژو 405 مدل 1384",
        "brand": "پژو",
        "model": "405",
        "year": 1384,
        "province": "گلستان",
        "city": "رامیان",
        "base_price": 0,
        "deadline": "1405/06/29",
        "organizer": "قوه قضاییه",
        "url": "https://mozayedegar.com/listing/1930277/",
        "description": "نمونه داده برای تست؛ در نسخه عملی از منبع مربوطه دریافت می‌شود."
    },
    {
        "id": "demo-guarantee-pickup-ahvaz",
        "title": "مزایده وانت دوکابین دولتی در اهواز",
        "brand": "نامشخص",
        "model": "وانت دوکابین",
        "year": 0,
        "province": "خوزستان",
        "city": "اهواز",
        "base_price": 0,
        "deadline": "1405/07/25",
        "organizer": "گمرک",
        "url": "https://mozayedegar.com/auction-listing?organization-ids=140",
        "description": "نمونه داده برای تست."
    }
]

class Auction(BaseModel):
    id: str
    title: str
    brand: str
    model: str
    year: int
    province: str
    city: str
    base_price: int
    deadline: str
    organizer: str
    url: str
    description: str

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/auctions", response_model=list[Auction])
def auctions(
    province: Optional[str] = None,
    model: Optional[str] = None,
    max_price: Optional[int] = Query(None, ge=0)
):
    result = AUCTIONS
    if province and province != "همه":
        result = [x for x in result if province in x["province"]]
    if model:
        result = [x for x in result if model.lower() in (x["model"] + " " + x["title"]).lower()]
    if max_price:
        result = [x for x in result if not x["base_price"] or x["base_price"] <= max_price]
    return result
